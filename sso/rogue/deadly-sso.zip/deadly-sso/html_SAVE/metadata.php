<?php

print_r($_SERVER);
function getIssuer(){
	$domain = "ngrok.io";
	$host = $_SERVER['HTTP_HOST'];
	if (strpos($host,$domain) > -1){
		$protocol = "https";
	}
	else
		$protocol = "http";

	$issuer = $protocol."://".$host;
	return $issuer;

}
echo getIssuer();
?>