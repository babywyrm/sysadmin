# SAML IdP Example

This simple demo codebase explains how you can integrate IdP capabilities into your website using LightSAML.

For a detailed walkthrough see https://medium.com/prosple-engineering/how-to-turn-your-php-website-into-a-saml-identity-provider-in-30-minutes-896c44724581
