<?php

// Autoloading libraries
require __DIR__ . '/vendor/autoload.php';
